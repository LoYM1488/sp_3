﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Anti_keylogger
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            if (name != "")
            {
                try
                {
                    Process[] localByName = Process.GetProcessesByName(name);
                    foreach (Process p in localByName)
                    {
                        if (p.ProcessName == name)
                        {
                            p.Kill();
                            MessageBoxButtons buttons = MessageBoxButtons.OK;
                            MessageBox.Show("Процесс успешно удалён", "Успешно", buttons);
                        }
                    }
                }
                catch
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Процесс не найден!", "Ошибка", buttons);
                }
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Поле не должно быть пустым!", "Ошибка", buttons);
            }
        }
    }
}
