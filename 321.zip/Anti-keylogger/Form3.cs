﻿using System;
using System.Windows.Forms;
using System.IO;

namespace Anti_keylogger
{
    public partial class Form3 : Form
    {
        private string folderName;

        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                folderName = folderBrowserDialog1.SelectedPath;
                textBox1.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                try
                {
                    Directory.Delete(folderName, true);
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Папка успешно удалена", "Успешно", buttons);
                }
                catch
                {
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    MessageBox.Show("Папка не обнаружена или вы не имеете доступа к ней!", "Ошибка", buttons);
                }
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show("Поле не должно быть пустым!", "Ошибка", buttons);
            }
        }
    }
}
