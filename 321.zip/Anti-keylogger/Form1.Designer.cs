﻿namespace Anti_keylogger
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button2.Location = new System.Drawing.Point(10, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(63, 37);
            this.button2.TabIndex = 1;
            this.button2.Text = "Esc";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button3.Location = new System.Drawing.Point(79, 83);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(63, 48);
            this.button3.TabIndex = 2;
            this.button3.Text = "!\r\n1";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button4.Location = new System.Drawing.Point(148, 83);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(63, 48);
            this.button4.TabIndex = 3;
            this.button4.Text = "@ \"\r\n2";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button5.Location = new System.Drawing.Point(217, 83);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(63, 48);
            this.button5.TabIndex = 4;
            this.button5.Text = "# №\r\n3";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button6.Location = new System.Drawing.Point(286, 83);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(63, 48);
            this.button6.TabIndex = 5;
            this.button6.Text = "$ ;\r\n4";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button7.Location = new System.Drawing.Point(355, 83);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(63, 48);
            this.button7.TabIndex = 6;
            this.button7.Text = "%\r\n5";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button8.Location = new System.Drawing.Point(424, 83);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(63, 48);
            this.button8.TabIndex = 7;
            this.button8.Text = "^ :\r\n6";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button9.Location = new System.Drawing.Point(493, 83);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(63, 48);
            this.button9.TabIndex = 8;
            this.button9.Text = "&& ?\r\n7";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button10.Location = new System.Drawing.Point(562, 83);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(63, 48);
            this.button10.TabIndex = 9;
            this.button10.Text = "*\r\n8";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button11.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button11.Location = new System.Drawing.Point(631, 83);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(63, 48);
            this.button11.TabIndex = 10;
            this.button11.Text = "(\r\n9";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button12.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button12.Location = new System.Drawing.Point(700, 83);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(63, 48);
            this.button12.TabIndex = 11;
            this.button12.Text = ")\r\n0";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button13.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button13.Location = new System.Drawing.Point(769, 83);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(63, 48);
            this.button13.TabIndex = 12;
            this.button13.Text = "_\r\n-";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button14.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button14.Location = new System.Drawing.Point(838, 83);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(74, 48);
            this.button14.TabIndex = 13;
            this.button14.Text = "+\r\n=";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button15.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button15.Location = new System.Drawing.Point(918, 83);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(136, 48);
            this.button15.TabIndex = 14;
            this.button15.Text = "Backspace";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button16.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button16.Location = new System.Drawing.Point(930, 143);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(124, 102);
            this.button16.TabIndex = 15;
            this.button16.Text = "Enter";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button17.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button17.Location = new System.Drawing.Point(12, 83);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(61, 48);
            this.button17.TabIndex = 16;
            this.button17.Text = "` ~\r\nЁ";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button18.Location = new System.Drawing.Point(10, 143);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(74, 48);
            this.button18.TabIndex = 17;
            this.button18.Text = "Tab";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button22.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button22.Location = new System.Drawing.Point(102, 305);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(63, 48);
            this.button22.TabIndex = 21;
            this.button22.Text = "Win";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button24.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button24.Location = new System.Drawing.Point(240, 305);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(454, 48);
            this.button24.TabIndex = 23;
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button25.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button25.Location = new System.Drawing.Point(769, 305);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(63, 48);
            this.button25.TabIndex = 25;
            this.button25.Text = "RU\r\nEN";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button26.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button26.Location = new System.Drawing.Point(838, 305);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(74, 48);
            this.button26.TabIndex = 26;
            this.button26.Text = "Я";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button29.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button29.Location = new System.Drawing.Point(90, 143);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(63, 48);
            this.button29.TabIndex = 29;
            this.button29.Text = "Q\r\nЙ";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button30.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button30.Location = new System.Drawing.Point(159, 143);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(63, 48);
            this.button30.TabIndex = 30;
            this.button30.Text = "W\r\nЦ";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button31.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button31.Location = new System.Drawing.Point(228, 143);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(63, 48);
            this.button31.TabIndex = 31;
            this.button31.Text = "E\r\nУ";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button32.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button32.Location = new System.Drawing.Point(297, 143);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(63, 48);
            this.button32.TabIndex = 32;
            this.button32.Text = "R\r\nК";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button33.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button33.Location = new System.Drawing.Point(366, 143);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(63, 48);
            this.button33.TabIndex = 33;
            this.button33.Text = "T\r\nЕ";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button34.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button34.Location = new System.Drawing.Point(435, 143);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(63, 48);
            this.button34.TabIndex = 34;
            this.button34.Text = "Y\r\nН";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button35.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button35.Location = new System.Drawing.Point(504, 143);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(63, 48);
            this.button35.TabIndex = 35;
            this.button35.Text = "U\r\nГ";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button36.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button36.Location = new System.Drawing.Point(573, 143);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(63, 48);
            this.button36.TabIndex = 36;
            this.button36.Text = "I\r\nШ";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button37.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button37.Location = new System.Drawing.Point(642, 143);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(63, 48);
            this.button37.TabIndex = 37;
            this.button37.Text = "O\r\nЩ";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button38.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button38.Location = new System.Drawing.Point(711, 143);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(63, 48);
            this.button38.TabIndex = 38;
            this.button38.Text = "P\r\nЗ";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button39.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button39.Location = new System.Drawing.Point(780, 143);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(63, 48);
            this.button39.TabIndex = 39;
            this.button39.Text = "[ {\r\nХ";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button40.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button40.Location = new System.Drawing.Point(849, 143);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(63, 48);
            this.button40.TabIndex = 40;
            this.button40.Text = "] }\r\nЪ";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button41.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button41.Location = new System.Drawing.Point(102, 197);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(63, 48);
            this.button41.TabIndex = 41;
            this.button41.Text = "A\r\nФ";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button42.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button42.Location = new System.Drawing.Point(171, 197);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(63, 48);
            this.button42.TabIndex = 42;
            this.button42.Text = "S\r\nЫ";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button43.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button43.Location = new System.Drawing.Point(240, 197);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(63, 48);
            this.button43.TabIndex = 43;
            this.button43.Text = "D\r\nВ";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button44.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button44.Location = new System.Drawing.Point(309, 197);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(63, 48);
            this.button44.TabIndex = 44;
            this.button44.Text = "F\r\nА";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button45.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button45.Location = new System.Drawing.Point(378, 197);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(63, 48);
            this.button45.TabIndex = 45;
            this.button45.Text = "G\r\nП";
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button46.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button46.Location = new System.Drawing.Point(447, 197);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(63, 48);
            this.button46.TabIndex = 46;
            this.button46.Text = "H\r\nР";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button47.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button47.Location = new System.Drawing.Point(516, 197);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(63, 48);
            this.button47.TabIndex = 47;
            this.button47.Text = "J\r\nО";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button48.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button48.Location = new System.Drawing.Point(585, 197);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(63, 48);
            this.button48.TabIndex = 48;
            this.button48.Text = "K\r\nЛ";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button49.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button49.Location = new System.Drawing.Point(654, 197);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(63, 48);
            this.button49.TabIndex = 49;
            this.button49.Text = "L\r\nД";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button50.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button50.Location = new System.Drawing.Point(723, 197);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(63, 48);
            this.button50.TabIndex = 50;
            this.button50.Text = "; :\r\nЖ";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button51.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button51.Location = new System.Drawing.Point(792, 197);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(63, 48);
            this.button51.TabIndex = 51;
            this.button51.Text = "\' \"\r\nЭ";
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button52.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button52.Location = new System.Drawing.Point(861, 197);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(63, 48);
            this.button52.TabIndex = 52;
            this.button52.Text = "\\ |\r\n\\ /";
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button53.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button53.Location = new System.Drawing.Point(148, 251);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(63, 48);
            this.button53.TabIndex = 53;
            this.button53.Text = "Z\r\nЯ";
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button54.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button54.Location = new System.Drawing.Point(217, 251);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(63, 48);
            this.button54.TabIndex = 54;
            this.button54.Text = "X\r\nЧ";
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button55.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button55.Location = new System.Drawing.Point(286, 251);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(63, 48);
            this.button55.TabIndex = 55;
            this.button55.Text = "C\r\nС";
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button56.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button56.Location = new System.Drawing.Point(355, 251);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(63, 48);
            this.button56.TabIndex = 56;
            this.button56.Text = "V\r\nМ";
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button57.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button57.Location = new System.Drawing.Point(424, 251);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(63, 48);
            this.button57.TabIndex = 57;
            this.button57.Text = "B\r\nИ";
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button58.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button58.Location = new System.Drawing.Point(493, 251);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(63, 48);
            this.button58.TabIndex = 58;
            this.button58.Text = "N\r\nТ";
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button59.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button59.Location = new System.Drawing.Point(562, 251);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(63, 48);
            this.button59.TabIndex = 59;
            this.button59.Text = "M\r\nЬ";
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button60.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button60.Location = new System.Drawing.Point(631, 251);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(63, 48);
            this.button60.TabIndex = 60;
            this.button60.Text = ", <\r\nБ";
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button61.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button61.Location = new System.Drawing.Point(700, 251);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(63, 48);
            this.button61.TabIndex = 61;
            this.button61.Text = ". >\r\nЮ";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button62.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button62.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button62.Location = new System.Drawing.Point(769, 251);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(63, 48);
            this.button62.TabIndex = 62;
            this.button62.Text = "/ ?\r\n. ,";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button63.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button63.Location = new System.Drawing.Point(991, 12);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(63, 37);
            this.button63.TabIndex = 63;
            this.button63.Text = "F12";
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button64.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button64.Location = new System.Drawing.Point(922, 12);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(63, 37);
            this.button64.TabIndex = 64;
            this.button64.Text = "F11";
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button65.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button65.Location = new System.Drawing.Point(853, 12);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(63, 37);
            this.button65.TabIndex = 65;
            this.button65.Text = "F10";
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button66.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button66.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button66.Location = new System.Drawing.Point(784, 12);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(63, 37);
            this.button66.TabIndex = 66;
            this.button66.Text = "F9";
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button67.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button67.Location = new System.Drawing.Point(671, 12);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(63, 37);
            this.button67.TabIndex = 67;
            this.button67.Text = "F8";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button68.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button68.Location = new System.Drawing.Point(602, 12);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(63, 37);
            this.button68.TabIndex = 68;
            this.button68.Text = "F7";
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button69.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button69.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button69.Location = new System.Drawing.Point(533, 12);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(63, 37);
            this.button69.TabIndex = 69;
            this.button69.Text = "F6";
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button70.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button70.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button70.Location = new System.Drawing.Point(464, 12);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(63, 37);
            this.button70.TabIndex = 70;
            this.button70.Text = "F5";
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button71.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button71.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button71.Location = new System.Drawing.Point(355, 12);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(63, 37);
            this.button71.TabIndex = 71;
            this.button71.Text = "F4";
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button72.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button72.Location = new System.Drawing.Point(286, 12);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(63, 37);
            this.button72.TabIndex = 72;
            this.button72.Text = "F3";
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button73.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button73.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button73.Location = new System.Drawing.Point(217, 12);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(63, 37);
            this.button73.TabIndex = 73;
            this.button73.Text = "F2";
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button74.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button74.Location = new System.Drawing.Point(148, 12);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(63, 37);
            this.button74.TabIndex = 74;
            this.button74.Text = "F1";
            this.button74.UseVisualStyleBackColor = false;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 24);
            this.label1.TabIndex = 75;
            this.label1.Text = "Текущий язык:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(144, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 24);
            this.label2.TabIndex = 76;
            this.label2.Text = "RU";
            // 
            // checkBox1
            // 
            this.checkBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox1.Location = new System.Drawing.Point(10, 251);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(132, 48);
            this.checkBox1.TabIndex = 77;
            this.checkBox1.Text = "Shift";
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox2.Location = new System.Drawing.Point(10, 197);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(86, 48);
            this.checkBox2.TabIndex = 78;
            this.checkBox2.Text = "Caps\r\nLock";
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox2.UseVisualStyleBackColor = false;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox3.Location = new System.Drawing.Point(12, 305);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(86, 48);
            this.checkBox3.TabIndex = 79;
            this.checkBox3.Text = "Ctrl";
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox3.UseVisualStyleBackColor = false;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox6.Location = new System.Drawing.Point(838, 251);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(216, 48);
            this.checkBox6.TabIndex = 82;
            this.checkBox6.Text = "Shift";
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox6.UseVisualStyleBackColor = false;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox7.Location = new System.Drawing.Point(918, 305);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(136, 48);
            this.checkBox7.TabIndex = 83;
            this.checkBox7.Text = "Ctrl";
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox7.UseVisualStyleBackColor = false;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox4.Location = new System.Drawing.Point(171, 305);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(63, 48);
            this.checkBox4.TabIndex = 88;
            this.checkBox4.Text = "Alt";
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox4.UseVisualStyleBackColor = false;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged_1);
            // 
            // checkBox5
            // 
            this.checkBox5.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.checkBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.checkBox5.Location = new System.Drawing.Point(700, 305);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(63, 48);
            this.checkBox5.TabIndex = 89;
            this.checkBox5.Text = "Alt";
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox5.UseVisualStyleBackColor = false;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button1.Location = new System.Drawing.Point(968, 360);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 35);
            this.button1.TabIndex = 90;
            this.button1.Text = "☼";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button19.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button19.Location = new System.Drawing.Point(1014, 360);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(40, 35);
            this.button19.TabIndex = 91;
            this.button19.Text = "•";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1066, 404);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Анти-кейлоггер";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button19;
    }
}

