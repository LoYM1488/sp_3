﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;

namespace Anti_keylogger
{
    public partial class Form1 : Form
    {
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams param = base.CreateParams;
                param.ExStyle |= 0x08000000;
                return param;
            }
        }

        string lang = "RU";
        bool Caps = false;
        bool Shift = false;
        bool Ctrl = false;
        bool Alt = false;
        bool Alt2 = false;
        bool Ctrl2 = false;
        bool Shift2 = false;
        bool lightTheme = true;
        private Random myrand = new Random();
        private string letters = "QqWwEeRrTtYyUuIiOoPp{[}]AaSsDdFfGgHhJjKkLl:;ZzXxCcVvBbNnMm<,>.?/ЙйЦцУуКкЕеНнГгШшЩщЗзХхЪъФфЫыВвАаПпРрОоЛлДдЖжЭэ/ЯяЧчСсМмИиТтЬьБбЮю,.1234567890";

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{ESC}");
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (lang == "RU")
            {
                lang = "EN";
                label2.Text = "EN";
            }
            else
            {
                lang = "RU";
                label2.Text = "RU";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                Caps = true;
                Shift2 = false;
                checkBox6.Checked = false;
                Shift = false;
                checkBox1.Checked = false;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
                if (lightTheme)
                {
                    checkBox2.BackColor = SystemColors.AppWorkspace;
                    checkBox6.BackColor = SystemColors.ButtonHighlight;
                    checkBox1.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox2.BackColor = SystemColors.Highlight;
                    checkBox6.BackColor = SystemColors.InfoText;
                    checkBox1.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Caps = false;
                if (lightTheme)
                {
                    checkBox2.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox2.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Shift = true;
                Shift2 = false;
                checkBox6.Checked = false;
                Caps = false;
                checkBox2.Checked = false;
                if (lightTheme)
                {
                    checkBox1.BackColor = SystemColors.AppWorkspace;
                    checkBox6.BackColor = SystemColors.ButtonHighlight;
                    checkBox2.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox1.BackColor = SystemColors.Highlight;
                    checkBox6.BackColor = SystemColors.InfoText;
                    checkBox2.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Shift = false;
                if (lightTheme)
                {
                    checkBox1.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox1.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                Ctrl = true;
                Ctrl2 = false;
                checkBox7.Checked = false;
                if (lightTheme)
                {
                    checkBox3.BackColor = SystemColors.AppWorkspace;
                    checkBox7.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox3.BackColor = SystemColors.Highlight;
                    checkBox7.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Ctrl = false;
                if (lightTheme)
                {
                    checkBox3.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox3.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox4_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                Alt = true;
                checkBox4.BackColor = SystemColors.AppWorkspace;
                Alt2 = false;
                checkBox5.Checked = false;
                if (lightTheme)
                {
                    checkBox4.BackColor = SystemColors.AppWorkspace;
                    checkBox5.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox4.BackColor = SystemColors.Highlight;
                    checkBox5.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Alt = false;
                if (lightTheme)
                {
                    checkBox4.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox4.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox5_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                Alt2 = true;
                Alt = false;
                checkBox4.Checked = false;
                if (lightTheme)
                {
                    checkBox5.BackColor = SystemColors.AppWorkspace;
                    checkBox4.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox5.BackColor = SystemColors.Highlight;
                    checkBox4.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Alt2 = false;
                if (lightTheme)
                {
                    checkBox5.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox5.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                Ctrl2 = true;
                Ctrl = false;
                checkBox3.Checked = false;
                if (lightTheme)
                {
                    checkBox7.BackColor = SystemColors.AppWorkspace;
                    checkBox3.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox7.BackColor = SystemColors.Highlight;
                    checkBox3.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Ctrl2 = false;
                if (lightTheme)
                {
                    checkBox7.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox7.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                Shift2 = true;
                Shift = false;
                checkBox1.Checked = false;
                Caps = false;
                checkBox2.Checked = false;
                if (lightTheme)
                {
                    checkBox6.BackColor = SystemColors.AppWorkspace;
                    checkBox1.BackColor = SystemColors.ButtonHighlight;
                    checkBox2.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox6.BackColor = SystemColors.Highlight;
                    checkBox1.BackColor = SystemColors.InfoText;
                    checkBox2.BackColor = SystemColors.InfoText;
                }
            }
            else
            {
                Shift2 = false;
                if (lightTheme)
                {
                    checkBox6.BackColor = SystemColors.ButtonHighlight;
                }
                else
                {
                    checkBox6.BackColor = SystemColors.InfoText;
                }
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{BACKSPACE}");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{TAB}");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{ENTER}");
        }

        private void button24_Click(object sender, EventArgs e)
        {
            SendKeys.Send(" ");
        }

        private void button74_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F1}");
        }

        private void button64_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F11}");
        }

        private void button73_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F2}");
        }
        
        private void button72_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F3}");
        }

        private void button71_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F4}");
        }

        private void button70_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F5}");
        }

        private void button69_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F6}");
        }

        private void button68_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F7}");
        }

        private void button67_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F8}");
        }

        private void button66_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F9}");
        }

        private void button65_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F10}");
        }

        private void button63_Click(object sender, EventArgs e)
        {
            SendKeys.Send("{F12}");
        }

        private void button26_Click(object sender, EventArgs e)
        {
            Process.Start("cmd.exe", "/C " + " start https://yandex.ru");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            SendKeys.Send("^{ESC}");
        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Q");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("q");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                Console.WriteLine(symb);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Й");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("й");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{q}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{q}");
                }
                else
                {
                    SendKeys.Send("%{й}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("W");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("w");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ц");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ц");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{w}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{w}");
                }
                else
                {
                    SendKeys.Send("%{ц}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("E");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("e");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("У");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("у");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{e}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{e}");
                }
                else
                {
                    SendKeys.Send("%{у}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("R");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("r");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("К");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("к");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{r}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{r}");
                }
                else
                {
                    SendKeys.Send("%{к}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("T");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("t");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Е");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("е");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{t}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{t}");
                }
                else
                {
                    SendKeys.Send("%{е}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Y");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("y");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Н");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("н");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{y}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{y}");
                }
                else
                {
                    SendKeys.Send("%{н}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("U");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("u");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Г");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("г");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{u}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{u}");
                }
                else
                {
                    SendKeys.Send("%{г}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("I");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("i");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ш");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ш");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{i}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{i}");
                }
                else
                {
                    SendKeys.Send("%{ш}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("O");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("o");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Щ");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("щ");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{o}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{o}");
                }
                else
                {
                    SendKeys.Send("%{щ}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button38_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("P");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("p");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("З");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("з");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{p}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{p}");
                }
                else
                {
                    SendKeys.Send("%{з}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("{");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("[");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Х");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("х");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{х}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("}");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("]");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Ъ");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("ъ");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{ъ}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("A");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("a");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ф");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ф");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{a}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{a}");
                }
                else
                {
                    SendKeys.Send("%{ф}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button42_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("S");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("s");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ы");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ы");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{s}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{s}");
                }
                else
                {
                    SendKeys.Send("%{ы}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button43_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("D");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("d");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("В");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("в");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{d}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{d}");
                }
                else
                {
                    SendKeys.Send("%{в}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button44_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("F");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("f");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("А");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("а");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{f}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{f}");
                }
                else
                {
                    SendKeys.Send("%{а}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button45_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("G");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("g");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("П");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("п");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{g}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{g}");
                }
                else
                {
                    SendKeys.Send("%{п}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button46_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("H");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("h");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Р");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("р");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{h}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{h}");
                }
                else
                {
                    SendKeys.Send("%{р}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button47_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("J");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("j");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("О");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("о");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{j}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{j}");
                }
                else
                {
                    SendKeys.Send("%{о}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button48_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("K");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("k");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Л");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("л");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{k}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{k}");
                }
                else
                {
                    SendKeys.Send("%{л}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button49_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("L");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("l");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Д");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("д");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{l}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{l}");
                }
                else
                {
                    SendKeys.Send("%{д}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button50_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText(":");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText(";");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Ж");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("ж");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{ж}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button51_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("\"");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("\'");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Э");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("э");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{э}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button52_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("|");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("\\");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("/");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("\\");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button53_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Z");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("z");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Я");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("я");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{z}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{z}");
                }
                else
                {
                    SendKeys.Send("%{я}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button54_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("X");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("x");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ч");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ч");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{x}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{x}");
                }
                else
                {
                    SendKeys.Send("%{ч}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button55_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("C");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("c");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("С");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("с");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{c}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{c}");
                }
                else
                {
                    SendKeys.Send("%{с}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button56_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("V");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("v");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("М");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("м");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{v}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{v}");
                }
                else
                {
                    SendKeys.Send("%{м}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button57_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("B");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("b");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("И");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("и");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{b}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{b}");
                }
                else
                {
                    SendKeys.Send("%{и}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button58_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("N");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("n");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Т");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("т");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{n}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{n}");
                }
                else
                {
                    SendKeys.Send("%{т}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button59_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (!Ctrl && !Ctrl2)
                {
                    if (lang == "EN")
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("M");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("m");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                    else
                    {
                        if (Caps || Shift || Shift2)
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("Ь");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                        else
                        {
                            int whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.SetText("ь");
                            SendKeys.Send("^{v}");
                            whl = myrand.Next(5, 20);
                            for (int i = 0; i < whl; i++)
                            {
                                int symb = myrand.Next(0, 141);
                                char arr = letters[symb];
                                string str1 = arr.ToString();
                                Clipboard.SetText(str1);
                                SendKeys.Send("^{v}");
                                SendKeys.Send("{BACKSPACE}");
                            }
                            Clipboard.Clear();
                        }
                    }
                }
                else
                {
                    SendKeys.Send("^{m}");
                }
            }
            else
            {
                if (lang == "EN")
                {
                    SendKeys.Send("%{m}");
                }
                else
                {
                    SendKeys.Send("%{ь}");
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button60_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("<");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText(",");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Б");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("б");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{б}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button61_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText(">");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText(".");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Ю");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("ю");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{ю}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button62_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("?");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("/");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText(",");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText(".");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (!Alt && !Alt2)
            {
                if (lang == "EN")
                {
                    if (Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("~");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("`");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
                else
                {
                    if (Caps || Shift || Shift2)
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("Ё");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                    else
                    {
                        int whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.SetText("ё");
                        SendKeys.Send("^{v}");
                        whl = myrand.Next(5, 20);
                        for (int i = 0; i < whl; i++)
                        {
                            int symb = myrand.Next(0, 141);
                            char arr = letters[symb];
                            string str1 = arr.ToString();
                            Clipboard.SetText(str1);
                            SendKeys.Send("^{v}");
                            SendKeys.Send("{BACKSPACE}");
                        }
                        Clipboard.Clear();
                    }
                }
            }
            else
            {
                SendKeys.Send("%{ё}");
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("!");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("1");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("@");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("2");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("\"");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("2");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("#");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("3");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("№");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("3");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("$");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("4");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText(";");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("4");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("%");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("5");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("^");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("6");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText(":");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("6");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (lang == "EN")
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("&");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("7");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            else
            {
                if (Shift || Shift2)
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("?");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
                else
                {
                    int whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.SetText("7");
                    SendKeys.Send("^{v}");
                    whl = myrand.Next(5, 20);
                    for (int i = 0; i < whl; i++)
                    {
                        int symb = myrand.Next(0, 141);
                        char arr = letters[symb];
                        string str1 = arr.ToString();
                        Clipboard.SetText(str1);
                        SendKeys.Send("^{v}");
                        SendKeys.Send("{BACKSPACE}");
                    }
                    Clipboard.Clear();
                }
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("*");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("8");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("(");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("9");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText(")");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("0");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("_");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("-");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (Shift || Shift2)
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("+");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            else
            {
                int whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.SetText("=");
                SendKeys.Send("^{v}");
                whl = myrand.Next(5, 20);
                for (int i = 0; i < whl; i++)
                {
                    int symb = myrand.Next(0, 141);
                    char arr = letters[symb];
                    string str1 = arr.ToString();
                    Clipboard.SetText(str1);
                    SendKeys.Send("^{v}");
                    SendKeys.Send("{BACKSPACE}");
                }
                Clipboard.Clear();
            }
            Shift2 = false;
            checkBox6.Checked = false;
            Shift = false;
            checkBox1.Checked = false;
            if (lightTheme)
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox1.BackColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox1.BackColor = SystemColors.InfoText;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lightTheme = true;
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.ForeColor = SystemColors.InfoText;
            button2.BackColor = SystemColors.ButtonHighlight;
            button2.ForeColor = SystemColors.InfoText;
            button3.BackColor = SystemColors.ButtonHighlight;
            button3.ForeColor = SystemColors.InfoText;
            button4.BackColor = SystemColors.ButtonHighlight;
            button4.ForeColor = SystemColors.InfoText;
            button5.BackColor = SystemColors.ButtonHighlight;
            button5.ForeColor = SystemColors.InfoText;
            button6.BackColor = SystemColors.ButtonHighlight;
            button6.ForeColor = SystemColors.InfoText;
            button7.BackColor = SystemColors.ButtonHighlight;
            button7.ForeColor = SystemColors.InfoText;
            button8.BackColor = SystemColors.ButtonHighlight;
            button8.ForeColor = SystemColors.InfoText;
            button9.BackColor = SystemColors.ButtonHighlight;
            button9.ForeColor = SystemColors.InfoText;
            button10.BackColor = SystemColors.ButtonHighlight;
            button10.ForeColor = SystemColors.InfoText;
            button11.BackColor = SystemColors.ButtonHighlight;
            button11.ForeColor = SystemColors.InfoText;
            button12.BackColor = SystemColors.ButtonHighlight;
            button12.ForeColor = SystemColors.InfoText;
            button13.BackColor = SystemColors.ButtonHighlight;
            button13.ForeColor = SystemColors.InfoText;
            button14.BackColor = SystemColors.ButtonHighlight;
            button14.ForeColor = SystemColors.InfoText;
            button15.BackColor = SystemColors.ButtonHighlight;
            button15.ForeColor = SystemColors.InfoText;
            button16.BackColor = SystemColors.ButtonHighlight;
            button16.ForeColor = SystemColors.InfoText;
            button17.BackColor = SystemColors.ButtonHighlight;
            button17.ForeColor = SystemColors.InfoText;
            button18.BackColor = SystemColors.ButtonHighlight;
            button18.ForeColor = SystemColors.InfoText;
            button19.BackColor = SystemColors.ButtonHighlight;
            button19.ForeColor = SystemColors.InfoText;
            button22.BackColor = SystemColors.ButtonHighlight;
            button22.ForeColor = SystemColors.InfoText;
            button24.BackColor = SystemColors.ButtonHighlight;
            button24.ForeColor = SystemColors.InfoText;
            button25.BackColor = SystemColors.ButtonHighlight;
            button25.ForeColor = SystemColors.InfoText;
            button26.BackColor = SystemColors.ButtonHighlight;
            button26.ForeColor = SystemColors.InfoText;
            button29.BackColor = SystemColors.ButtonHighlight;
            button29.ForeColor = SystemColors.InfoText;
            button30.BackColor = SystemColors.ButtonHighlight;
            button30.ForeColor = SystemColors.InfoText;
            button31.BackColor = SystemColors.ButtonHighlight;
            button31.ForeColor = SystemColors.InfoText;
            button32.BackColor = SystemColors.ButtonHighlight;
            button32.ForeColor = SystemColors.InfoText;
            button33.BackColor = SystemColors.ButtonHighlight;
            button33.ForeColor = SystemColors.InfoText;
            button34.BackColor = SystemColors.ButtonHighlight;
            button34.ForeColor = SystemColors.InfoText;
            button35.BackColor = SystemColors.ButtonHighlight;
            button35.ForeColor = SystemColors.InfoText;
            button36.BackColor = SystemColors.ButtonHighlight;
            button36.ForeColor = SystemColors.InfoText;
            button37.BackColor = SystemColors.ButtonHighlight;
            button37.ForeColor = SystemColors.InfoText;
            button38.BackColor = SystemColors.ButtonHighlight;
            button38.ForeColor = SystemColors.InfoText;
            button39.BackColor = SystemColors.ButtonHighlight;
            button39.ForeColor = SystemColors.InfoText;
            button40.BackColor = SystemColors.ButtonHighlight;
            button40.ForeColor = SystemColors.InfoText;
            button41.BackColor = SystemColors.ButtonHighlight;
            button41.ForeColor = SystemColors.InfoText;
            button42.BackColor = SystemColors.ButtonHighlight;
            button42.ForeColor = SystemColors.InfoText;
            button43.BackColor = SystemColors.ButtonHighlight;
            button43.ForeColor = SystemColors.InfoText;
            button44.BackColor = SystemColors.ButtonHighlight;
            button44.ForeColor = SystemColors.InfoText;
            button45.BackColor = SystemColors.ButtonHighlight;
            button45.ForeColor = SystemColors.InfoText;
            button46.BackColor = SystemColors.ButtonHighlight;
            button46.ForeColor = SystemColors.InfoText;
            button47.BackColor = SystemColors.ButtonHighlight;
            button47.ForeColor = SystemColors.InfoText;
            button48.BackColor = SystemColors.ButtonHighlight;
            button48.ForeColor = SystemColors.InfoText;
            button49.BackColor = SystemColors.ButtonHighlight;
            button49.ForeColor = SystemColors.InfoText;
            button50.BackColor = SystemColors.ButtonHighlight;
            button50.ForeColor = SystemColors.InfoText;
            button51.BackColor = SystemColors.ButtonHighlight;
            button51.ForeColor = SystemColors.InfoText;
            button52.BackColor = SystemColors.ButtonHighlight;
            button52.ForeColor = SystemColors.InfoText;
            button53.BackColor = SystemColors.ButtonHighlight;
            button53.ForeColor = SystemColors.InfoText;
            button54.BackColor = SystemColors.ButtonHighlight;
            button54.ForeColor = SystemColors.InfoText;
            button55.BackColor = SystemColors.ButtonHighlight;
            button55.ForeColor = SystemColors.InfoText;
            button56.BackColor = SystemColors.ButtonHighlight;
            button56.ForeColor = SystemColors.InfoText;
            button57.BackColor = SystemColors.ButtonHighlight;
            button57.ForeColor = SystemColors.InfoText;
            button58.BackColor = SystemColors.ButtonHighlight;
            button58.ForeColor = SystemColors.InfoText;
            button59.BackColor = SystemColors.ButtonHighlight;
            button59.ForeColor = SystemColors.InfoText;
            button60.BackColor = SystemColors.ButtonHighlight;
            button60.ForeColor = SystemColors.InfoText;
            button61.BackColor = SystemColors.ButtonHighlight;
            button61.ForeColor = SystemColors.InfoText;
            button62.BackColor = SystemColors.ButtonHighlight;
            button62.ForeColor = SystemColors.InfoText;
            button63.BackColor = SystemColors.ButtonHighlight;
            button63.ForeColor = SystemColors.InfoText;
            button64.BackColor = SystemColors.ButtonHighlight;
            button64.ForeColor = SystemColors.InfoText;
            button65.BackColor = SystemColors.ButtonHighlight;
            button65.ForeColor = SystemColors.InfoText;
            button66.BackColor = SystemColors.ButtonHighlight;
            button66.ForeColor = SystemColors.InfoText;
            button67.BackColor = SystemColors.ButtonHighlight;
            button67.ForeColor = SystemColors.InfoText;
            button68.BackColor = SystemColors.ButtonHighlight;
            button68.ForeColor = SystemColors.InfoText;
            button69.BackColor = SystemColors.ButtonHighlight;
            button69.ForeColor = SystemColors.InfoText;
            button70.BackColor = SystemColors.ButtonHighlight;
            button70.ForeColor = SystemColors.InfoText;
            button71.BackColor = SystemColors.ButtonHighlight;
            button71.ForeColor = SystemColors.InfoText;
            button72.BackColor = SystemColors.ButtonHighlight;
            button72.ForeColor = SystemColors.InfoText;
            button73.BackColor = SystemColors.ButtonHighlight;
            button73.ForeColor = SystemColors.InfoText;
            button74.BackColor = SystemColors.ButtonHighlight;
            button74.ForeColor = SystemColors.InfoText;
            if (checkBox1.Checked)
            {
                checkBox1.BackColor = SystemColors.AppWorkspace;
                checkBox1.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox1.BackColor = SystemColors.ButtonHighlight;
                checkBox1.ForeColor = SystemColors.InfoText;
            }
            if (checkBox2.Checked)
            {
                checkBox2.BackColor = SystemColors.AppWorkspace;
                checkBox2.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox2.BackColor = SystemColors.ButtonHighlight;
                checkBox2.ForeColor = SystemColors.InfoText;
            }
            if (checkBox3.Checked)
            {
                checkBox3.BackColor = SystemColors.AppWorkspace;
                checkBox3.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox3.BackColor = SystemColors.ButtonHighlight;
                checkBox3.ForeColor = SystemColors.InfoText;
            }
            if (checkBox4.Checked)
            {
                checkBox4.BackColor = SystemColors.AppWorkspace;
                checkBox4.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox4.BackColor = SystemColors.ButtonHighlight;
                checkBox4.ForeColor = SystemColors.InfoText;
            }
            if (checkBox5.Checked)
            {
                checkBox5.BackColor = SystemColors.AppWorkspace;
                checkBox5.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox5.BackColor = SystemColors.ButtonHighlight;
                checkBox5.ForeColor = SystemColors.InfoText;
            }
            if (checkBox6.Checked)
            {
                checkBox6.BackColor = SystemColors.AppWorkspace;
                checkBox6.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox6.BackColor = SystemColors.ButtonHighlight;
                checkBox6.ForeColor = SystemColors.InfoText;
            }
            if (checkBox7.Checked)
            {
                checkBox7.BackColor = SystemColors.AppWorkspace;
                checkBox7.ForeColor = SystemColors.InfoText;
            }
            else
            {
                checkBox7.BackColor = SystemColors.ButtonHighlight;
                checkBox7.ForeColor = SystemColors.InfoText;
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            lightTheme = false;
            button1.BackColor = SystemColors.InfoText;
            button1.ForeColor = SystemColors.ButtonHighlight;
            button2.BackColor = SystemColors.InfoText;
            button2.ForeColor = SystemColors.ButtonHighlight;
            button3.BackColor = SystemColors.InfoText;
            button3.ForeColor = SystemColors.ButtonHighlight;
            button4.BackColor = SystemColors.InfoText;
            button4.ForeColor = SystemColors.ButtonHighlight;
            button5.BackColor = SystemColors.InfoText;
            button5.ForeColor = SystemColors.ButtonHighlight;
            button6.BackColor = SystemColors.InfoText;
            button6.ForeColor = SystemColors.ButtonHighlight;
            button7.BackColor = SystemColors.InfoText;
            button7.ForeColor = SystemColors.ButtonHighlight;
            button8.BackColor = SystemColors.InfoText;
            button8.ForeColor = SystemColors.ButtonHighlight;
            button9.BackColor = SystemColors.InfoText;
            button9.ForeColor = SystemColors.ButtonHighlight;
            button10.BackColor = SystemColors.InfoText;
            button10.ForeColor = SystemColors.ButtonHighlight;
            button11.BackColor = SystemColors.InfoText;
            button11.ForeColor = SystemColors.ButtonHighlight;
            button12.BackColor = SystemColors.InfoText;
            button12.ForeColor = SystemColors.ButtonHighlight;
            button13.BackColor = SystemColors.InfoText;
            button13.ForeColor = SystemColors.ButtonHighlight;
            button14.BackColor = SystemColors.InfoText;
            button14.ForeColor = SystemColors.ButtonHighlight;
            button15.BackColor = SystemColors.InfoText;
            button15.ForeColor = SystemColors.ButtonHighlight;
            button16.BackColor = SystemColors.InfoText;
            button16.ForeColor = SystemColors.ButtonHighlight;
            button17.BackColor = SystemColors.InfoText;
            button17.ForeColor = SystemColors.ButtonHighlight;
            button18.BackColor = SystemColors.InfoText;
            button18.ForeColor = SystemColors.ButtonHighlight;
            button19.BackColor = SystemColors.InfoText;
            button19.ForeColor = SystemColors.ButtonHighlight;
            button22.BackColor = SystemColors.InfoText;
            button22.ForeColor = SystemColors.ButtonHighlight;
            button24.BackColor = SystemColors.InfoText;
            button24.ForeColor = SystemColors.ButtonHighlight;
            button25.BackColor = SystemColors.InfoText;
            button25.ForeColor = SystemColors.ButtonHighlight;
            button26.BackColor = SystemColors.InfoText;
            button26.ForeColor = SystemColors.ButtonHighlight;
            button29.BackColor = SystemColors.InfoText;
            button29.ForeColor = SystemColors.ButtonHighlight;
            button30.BackColor = SystemColors.InfoText;
            button30.ForeColor = SystemColors.ButtonHighlight;
            button31.BackColor = SystemColors.InfoText;
            button31.ForeColor = SystemColors.ButtonHighlight;
            button32.BackColor = SystemColors.InfoText;
            button32.ForeColor = SystemColors.ButtonHighlight;
            button33.BackColor = SystemColors.InfoText;
            button33.ForeColor = SystemColors.ButtonHighlight;
            button34.BackColor = SystemColors.InfoText;
            button34.ForeColor = SystemColors.ButtonHighlight;
            button35.BackColor = SystemColors.InfoText;
            button35.ForeColor = SystemColors.ButtonHighlight;
            button36.BackColor = SystemColors.InfoText;
            button36.ForeColor = SystemColors.ButtonHighlight;
            button37.BackColor = SystemColors.InfoText;
            button37.ForeColor = SystemColors.ButtonHighlight;
            button38.BackColor = SystemColors.InfoText;
            button38.ForeColor = SystemColors.ButtonHighlight;
            button39.BackColor = SystemColors.InfoText;
            button39.ForeColor = SystemColors.ButtonHighlight;
            button40.BackColor = SystemColors.InfoText;
            button40.ForeColor = SystemColors.ButtonHighlight;
            button41.BackColor = SystemColors.InfoText;
            button41.ForeColor = SystemColors.ButtonHighlight;
            button42.BackColor = SystemColors.InfoText;
            button42.ForeColor = SystemColors.ButtonHighlight;
            button43.BackColor = SystemColors.InfoText;
            button43.ForeColor = SystemColors.ButtonHighlight;
            button44.BackColor = SystemColors.InfoText;
            button44.ForeColor = SystemColors.ButtonHighlight;
            button45.BackColor = SystemColors.InfoText;
            button45.ForeColor = SystemColors.ButtonHighlight;
            button46.BackColor = SystemColors.InfoText;
            button46.ForeColor = SystemColors.ButtonHighlight;
            button47.BackColor = SystemColors.InfoText;
            button47.ForeColor = SystemColors.ButtonHighlight;
            button48.BackColor = SystemColors.InfoText;
            button48.ForeColor = SystemColors.ButtonHighlight;
            button49.BackColor = SystemColors.InfoText;
            button49.ForeColor = SystemColors.ButtonHighlight;
            button50.BackColor = SystemColors.InfoText;
            button50.ForeColor = SystemColors.ButtonHighlight;
            button51.BackColor = SystemColors.InfoText;
            button51.ForeColor = SystemColors.ButtonHighlight;
            button52.BackColor = SystemColors.InfoText;
            button52.ForeColor = SystemColors.ButtonHighlight;
            button53.BackColor = SystemColors.InfoText;
            button53.ForeColor = SystemColors.ButtonHighlight;
            button54.BackColor = SystemColors.InfoText;
            button54.ForeColor = SystemColors.ButtonHighlight;
            button55.BackColor = SystemColors.InfoText;
            button55.ForeColor = SystemColors.ButtonHighlight;
            button56.BackColor = SystemColors.InfoText;
            button56.ForeColor = SystemColors.ButtonHighlight;
            button57.BackColor = SystemColors.InfoText;
            button57.ForeColor = SystemColors.ButtonHighlight;
            button58.BackColor = SystemColors.InfoText;
            button58.ForeColor = SystemColors.ButtonHighlight;
            button59.BackColor = SystemColors.InfoText;
            button59.ForeColor = SystemColors.ButtonHighlight;
            button60.BackColor = SystemColors.InfoText;
            button60.ForeColor = SystemColors.ButtonHighlight;
            button61.BackColor = SystemColors.InfoText;
            button61.ForeColor = SystemColors.ButtonHighlight;
            button62.BackColor = SystemColors.InfoText;
            button62.ForeColor = SystemColors.ButtonHighlight;
            button63.BackColor = SystemColors.InfoText;
            button63.ForeColor = SystemColors.ButtonHighlight;
            button64.BackColor = SystemColors.InfoText;
            button64.ForeColor = SystemColors.ButtonHighlight;
            button65.BackColor = SystemColors.InfoText;
            button65.ForeColor = SystemColors.ButtonHighlight;
            button66.BackColor = SystemColors.InfoText;
            button66.ForeColor = SystemColors.ButtonHighlight;
            button67.BackColor = SystemColors.InfoText;
            button67.ForeColor = SystemColors.ButtonHighlight;
            button68.BackColor = SystemColors.InfoText;
            button68.ForeColor = SystemColors.ButtonHighlight;
            button69.BackColor = SystemColors.InfoText;
            button69.ForeColor = SystemColors.ButtonHighlight;
            button70.BackColor = SystemColors.InfoText;
            button70.ForeColor = SystemColors.ButtonHighlight;
            button71.BackColor = SystemColors.InfoText;
            button71.ForeColor = SystemColors.ButtonHighlight;
            button72.BackColor = SystemColors.InfoText;
            button72.ForeColor = SystemColors.ButtonHighlight;
            button73.BackColor = SystemColors.InfoText;
            button73.ForeColor = SystemColors.ButtonHighlight;
            button74.BackColor = SystemColors.InfoText;
            button74.ForeColor = SystemColors.ButtonHighlight;
            if (checkBox1.Checked)
            {
                checkBox1.BackColor = SystemColors.Highlight;
                checkBox1.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox1.BackColor = SystemColors.InfoText;
                checkBox1.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox2.Checked)
            {
                checkBox2.BackColor = SystemColors.Highlight;
                checkBox2.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox2.BackColor = SystemColors.InfoText;
                checkBox2.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox3.Checked)
            {
                checkBox3.BackColor = SystemColors.Highlight;
                checkBox3.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox3.BackColor = SystemColors.InfoText;
                checkBox3.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox4.Checked)
            {
                checkBox4.BackColor = SystemColors.Highlight;
                checkBox4.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox4.BackColor = SystemColors.InfoText;
                checkBox4.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox5.Checked)
            {
                checkBox5.BackColor = SystemColors.Highlight;
                checkBox5.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox5.BackColor = SystemColors.InfoText;
                checkBox5.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox6.Checked)
            {
                checkBox6.BackColor = SystemColors.Highlight;
                checkBox6.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox6.BackColor = SystemColors.InfoText;
                checkBox6.ForeColor = SystemColors.ButtonHighlight;
            }
            if (checkBox7.Checked)
            {
                checkBox7.BackColor = SystemColors.Highlight;
                checkBox7.ForeColor = SystemColors.ButtonHighlight;
            }
            else
            {
                checkBox7.BackColor = SystemColors.InfoText;
                checkBox7.ForeColor = SystemColors.ButtonHighlight;
            }
        }
    }
}
